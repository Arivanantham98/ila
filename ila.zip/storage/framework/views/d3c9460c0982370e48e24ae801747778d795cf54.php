<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Indo Law Associates</title>
    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/favicon.png" />

    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />

    <!-- animate -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>" />

    <!-- fontawesome -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.css')); ?>" />

    <!-- themify -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/themify-icons.css')); ?>" />

    <!-- flaticon -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/flaticon.css')); ?>" />

    <!-- slick -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slick.css')); ?>">

    <!-- REVOLUTION LAYERS STYLES -->

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('revolution/css/layers.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('revolution/css/settings.css')); ?>">

    <!-- prettyphoto -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/prettyPhoto.css')); ?>">

    <!-- shortcodes -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/shortcodes.css')); ?>" />

    <!-- main -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>" />

    <!-- responsive -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" />

    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/reset.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/ionicon.min.css')); ?>">

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

    <style>
        .login-popup {
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            z-index: 1099;
            background-color: rgba(0, 0, 0, 0.6);
            visibility: hidden;
            opacity: 0;
            transition: all 1s ease;
        }

        .login-popup.show {
            visibility: visible;
            opacity: 1;
        }

        .login-popup .box {
            background-color: #ffffff;
            width: 750px;
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            display: flex;
            flex-wrap: wrap;
            opacity: 0;
            margin-left: 50px;
            transition: all 1s ease;

        }

        .login-popup.show .box {
            opacity: 1;
            margin-left: 0;
        }

        .login-popup .box .img-area {
            flex: 0 0 50%;
            max-width: 50%;
            position: relative;
            overflow: hidden;
            padding: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-popup .box .img-area h1 {
            font-size: 30px;
        }

        .login-popup .box .img-area .img {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-image: url('img/bg.jpg');
            background-size: cover;
            background-position: center;
            animation: zoomInOut 7s linear infinite;
            z-index: -1;

        }

        @keyframes  zoomInOut {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.1);
            }
        }

        .login-popup .box .form {
            flex: 0 0 50%;
            max-width: 50%;
            padding: 40px 30px;
        }

        .login-popup .box .form h1 {
            color: #000000;
            font-size: 30px;
            margin: 0 0 30px;
        }

        .login-popup .box .form .form-control {
            height: 45px;
            margin-bottom: 30px;
            width: 100%;
            border: none;
            border-bottom: 1px solid #cccccc;
            font-size: 15px;
            color: #000000;
        }

        .login-popup .box .form .form-control:focus {
            outline: none;
        }

        .login-popup .box .form label {
            font-size: 15px;
            color: #555555;
        }

        .login-popup .box .form .btn {
            width: 100%;
            background-color: #E91E63;
            margin-top: 40px;
            height: 45px;
            border: none;
            border-radius: 25px;
            font-size: 15px;
            text-transform: uppercase;
            color: #ffffff;
            cursor: pointer;
        }

        .login-popup .box .form .btn:focus {
            outline: none;
        }

        .login-popup .box .form .close {
            position: absolute;
            right: 10px;
            top: 0px;
            font-size: 30px;
            cursor: pointer;
        }

        /*responsive*/
        @media(max-width: 767px) {
            .login-popup .box {
                width: calc(100% - 30px);
            }

            .login-popup .box .img-area {
                display: none;
            }

            .login-popup .box .form {
                flex: 0 0 100%;
                max-width: 100%;
            }
        }

    </style>

</head>

<body>
    <div class="page">

        <!-- preloader start -->
        <div id="preloader">
            <div id="status">&nbsp;</div>
        </div>

        <div class="login-popup">
            <div class="row justify-content-md-center align-items-center">
                <div class="col-sm-6">
                    <div class="card text-center">
                        <div class="card-header">
                          Featured
                        </div>
                        <div class="card-body">
                            <div class="alert alert-danger" id="error" style="display: none;"></div>
                            <div class="card">
                                <div class="card-header">
                                    Enter Phone Number
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-success" id="sentSuccess" style="display: none;"></div>
                                    <form>
                                        <label>Phone Number:</label>
                                        <input type="text" id="number" class="form-control" placeholder="+91********">
                                        <div id="recaptcha-container"></div>
                                        <button type="button" class="btn btn-success" onclick="phoneSendAuth();">SendCode</button>
                                    </form>
                                </div>
                            </div>
                            <div class="card" style="margin-top: 10px">
                                <div class="card-header">
                                    Enter Verification code
                                </div>
                                <div class="card-body">
                                    <div class="alert alert-success" id="successRegsiter" style="display: none;"></div>
                                    <form>
                                        <input type="text" id="verificationCode" class="form-control"
                                            placeholder="Enter verification code">
                                        <button type="button" class="btn btn-success" onclick="codeverify();">Verify code</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                      </div>
                   
                </div>
            </div>
        </div>
        <!-- preloader end -->
        <!--header start-->
        <header class="header">
            <div class="containers">
                <div class="wrapper">
                    <div class="header-item-left">
                        
                        <a href="<?php echo e(url('/')); ?>"> <img src="<?php echo e(asset('./images/logo/ila-logo.png')); ?>"
                                alt=""></a>
                    </div>
                    <!-- Section: Navbar Menu -->
                    <div class="header-item-center">
                        <div class="overlay"></div>
                        <nav class="menu">
                            <div class="menu-mobile-header">
                                <button type="button" class="menu-mobile-arrow"><i
                                        class="ion ion-ios-arrow-back"></i></button>
                                <div class="menu-mobile-title"></div>
                                <button type="button" class="menu-mobile-close"><i
                                        class="ion ion-ios-close"></i></button>
                            </div>
                            <ul class="menu-section">
                                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                                
                                <li class="menu-item-has-children">
                                    <a href="#">Book a Lawyer <i class="ion ion-ios-arrow-down"></i></a>
                                    <div class="menu-subs menu-mega menu-column-4">
                                        <div class="list-item">
                                            <h4 class="title">Personal/Family
                                            </h4>
                                            <ul>
                                                <li><a href="<?php echo e(route('perosnalfamily.divorce')); ?>">Divorce</a></li>
                                                <li><a href="<?php echo e(route('perosnalfamily.familydispute')); ?>">Family
                                                        Dispute</a></li>
                                                <li><a href="<?php echo e(route('perosnalfamily.childcustody')); ?>">Child
                                                        Custody</a></li>
                                                <li><a href="<?php echo e(route('perosnalfamily.muslimlaw')); ?>">Muslim Law</a>
                                                </li>
                                                <li><a href="<?php echo e(route('perosnalfamily.medicalnegligence')); ?>">Medical
                                                        Negligence</a></li>
                                                <li><a href="<?php echo e(route('perosnalfamily.motoraccident')); ?>">Motor
                                                        Accident</a></li>
                                                <li><a
                                                        href="<?php echo e(route('perosnalfamily.willstrust')); ?>">Wills/Trusts</a>
                                                </li>
                                                <li><a
                                                        href="<?php echo e(route('perosnalfamily.labourservices')); ?>">Labour&Service</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="list-item">
                                            <h4 class="title">Corporate
                                            </h4>
                                            <ul>
                                                <li><a href="<?php echo e(route('croporatelaw.arbiration')); ?>">Arbitration</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.tradecopyrights')); ?>">Trademark & Copyright</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.customercentralexcercise')); ?>">Customs & Central Excise</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.startup')); ?>">Startup</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.bankingfinance')); ?>">Banking/Finance</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.gst')); ?>">GST</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.croporate')); ?>">Corporate</a></li>
                                                <li><a href="<?php echo e(route('croporatelaw.tax')); ?>">Tax</a></li>
                                            </ul>
                                        </div>

                                        <div class="list-item">
                                            <h4 class="title">Civil/Debt Matters</h4>
                                            <ul>
                                                <li><a href="<?php echo e(route('civildebt.documentation')); ?>">Documentation</a></li>
                                                <li><a href="<?php echo e(route('civildebt.consumercourt')); ?>">Consumer Court</a></li>
                                                <li><a href="<?php echo e(route('civildebt.civil')); ?>">Civil</a></li>
                                                <li><a href="<?php echo e(route('civildebt.chequebounce')); ?>">Cheque Bounce</a></li>
                                                <li><a href="<?php echo e(route('civildebt.recovery')); ?>">Recovery</a></li>

                                            </ul>
                                        </div>
                                        <div class="list-item">
                                            <h4 class="title">Criminal/Property</h4>
                                            <ul>
                                                <li><a href="<?php echo e(route('criminalproperty.criminal')); ?>">Criminal</a></li>
                                                <li><a href="<?php echo e(route('criminalproperty.property')); ?>">Property</a></li>
                                                <li><a href="<?php echo e(route('criminalproperty.landlordtenant')); ?>">Landlord/Tenant</a></li>
                                                <li><a href="<?php echo e(route('criminalproperty.cybercrime')); ?>">Cyber Crime</a></li>

                                            </ul>
                                        </div>

                                    </div>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">Legal Services <i class="ion ion-ios-arrow-down"></i></a>
                                    <div class="menu-subs menu-mega menu-column-4">
                                        <div class="list-item">
                                            <h4 class="title">Family/Matrimonial</h4>
                                            <ul>
                                                <li><a href="#">Mutual Divorce</a></li>
                                                <li><a href="#">Marriage Registration</a></li>
                                                <li><a href="#">Court Marriage</a></li>
                                                <li><a href="#">Divorce Notice</a></li>
                                                <li><a href="#">Marriage Counselling</a></li>
                                                <li><a href="#">Wil Drafting</a></li>

                                            </ul>
                                        </div>
                                        <div class="list-item">
                                            <h4 class="title">Civil Law/Property</h4>
                                            <ul>
                                                <li><a href="#">Succession Certificate</a></li>
                                                <li><a href="#">Property Verification</a></li>
                                                <li><a href="#">Property Registration</a></li>
                                                <li><a href="#">Gift Deed Drafting</a></li>
                                                <li><a href="#">Lease Agreement Drafting </a></li>
                                                <li><a href="#">Lease Registration</a></li>
                                            </ul>

                                        </div>
                                        <div class="list-item">
                                            <h4 class="title">Documentation
                                            </h4>
                                            <ul>
                                                <li><a href="#">MoU</a></li>
                                                <li><a href="#">Name Change</a></li>
                                                <li><a href="#">Sale Deed Registration</a></li>
                                                <li><a href="#">Gift Deed Drafting</a></li>
                                                <li><a href="#">Will Registration</a></li>
                                                <li><a href="#">Power of Attorney</a></li>
                                            </ul>

                                        </div>
                                        <div class="list-item">
                                            <h4 class="title">Legal Notice</h4>
                                            <ul>
                                                <li><a href="#">Divorce Notice</a></li>
                                                <li><a href="#">Tenant Eviction Notice </a></li>
                                                <li><a href="#">Refund of Security Notice</a></li>
                                                <li><a href="#">Faulty Product Notice</a></li>
                                                <li><a href="#">Cheque Bounce Notice</a></li>
                                                <li><a href="#">Recovery Notice of Dues
                                                    </a></li>
                                            </ul>

                                        </div>
                                        



                                    </div>
                                </li>
                                
                                <li class="menu-item-has-children">
                                    <a href="#">Other Services <i class="ion ion-ios-arrow-down"></i></a>
                                    <div class="menu-subs menu-column-1">
                                        <ul>
                                            <li><a href="#">Other Services</a></li>
                                            <li><a href="#">Paralegal Services</a></li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="menu-item-has-children">
                                    <a href="#">About <i class="ion ion-ios-arrow-down"></i></a>
                                    <div class="menu-subs menu-column-1">
                                        <ul>
                                            <li><a href="<?php echo e(url('/about')); ?>">About us</a></li>
                                            <li><a href="<?php echo e(url('/contact')); ?>">contact us</a></li>
                                            <li><a href="#">Privacy & Policy</a></>
                                            <li><a href="#">Term of Cookies</a></>
                                        </ul>
                                    </div>
                                </li>
                                
                            </ul>
                        </nav>
                    </div>

                    <div class="header-item-right">
                        <button class="tp-caption ttm-btn ttm-btn-style-fill ttm-btn-color-skincolor">Book an
                            appointment</button>

                        <button type="button" class="menu-mobile-trigger">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                    </div>

                </div>
            </div>
        </header>

        

        
        <?php echo $__env->yieldContent('content'); ?>



        <!--back-to-top start-->
        <a id="totop" href="#top">
            <i class="fa fa-angle-up"></i>
        </a>
        <!--back-to-top end-->

    </div><!-- page end -->

    <script>
      

  const loginPopup = document.querySelector(".login-popup");
  const close = document.querySelector(".close");


  window.addEventListener("load",function(){
 
   showPopup();
   // setTimeout(function(){
   //   loginPopup.classList.add("show");
   // },5000)

  })

  function showPopup(){
        const timeLimit = 5 // seconds;
        let i=0;
        const timer = setInterval(function(){
         i++;
         if(i == timeLimit){
          clearInterval(timer);
          loginPopup.classList.add("show");
         } 
         console.log(i)
        },1000);
  }

  close.addEventListener("click",function(){
    loginPopup.classList.remove("show");

  $("#btnClose").click(function (e)
  {
    
  })
     localStorage["PopupShown"] = 'yes'; //Save in the sessionStorage if the modal has been shown
  });
  


      
    </script>
     <script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>
     <script>
         const firebaseConfig = {
             apiKey: "AIzaSyB6p_z1sUqiVvNwVFmzbaBujTjgqIsM8mY",
             authDomain: "indolaw-associates.firebaseapp.com",
             projectId: "indolaw-associates",
             storageBucket: "indolaw-associates.appspot.com",
             messagingSenderId: "772447660818",
             appId: "1:772447660818:web:ea8c8e03d55c198019e1cb",
             measurementId: "G-2KSQPKJK1M"
         };
 
         firebase.initializeApp(firebaseConfig);
     </script>
     <script type="text/javascript">
         window.onload = function() {
             render();
         };
 
         function render() {
             window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
             recaptchaVerifier.render();
         }
 
         function phoneSendAuth() {
 
             var number = $("#number").val();
 
             firebase.auth().signInWithPhoneNumber(number, window.recaptchaVerifier).then(function(confirmationResult) {
 
                 window.confirmationResult = confirmationResult;
                 coderesult = confirmationResult;
                 console.log(coderesult);
 
                 $("#sentSuccess").text("Message Sent Successfully.");
                 $("#sentSuccess").show();
 
             }).catch(function(error) {
                 $("#error").text(error.message);
                 $("#error").show();
             });
 
         }
 
         function codeverify() {
 
             var code = $("#verificationCode").val();
 
             coderesult.confirm(code).then(function(result) {
                 var user = result.user;
 
                 $("#successRegsiter").text("you are register Successfully.");
                 $("#successRegsiter").show();
 
             }).catch(function(error) {
                 $("#error").text(error.message);
                 $("#error").show();
             });
         }
     </script>

    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.easing.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-waypoints.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery-validate.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.prettyPhoto.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/numinate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

    <!-- Revolution Slider -->
    <script src="<?php echo e(asset('revolution/js/jquery.themepunch.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/jquery.themepunch.revolution.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/slider.js')); ?>"></script>

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->

    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.actions.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.kenburn.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.layeranimation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.migration.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.navigation.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.parallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.slideanims.min.js')); ?>"></script>
    <script src="<?php echo e(asset('revolution/js/extensions/revolution.extension.video.min.js')); ?>"></script>
    
    
</body>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\Users\hr\Desktop\ila\resources\views/layouts/master.blade.php ENDPATH**/ ?>